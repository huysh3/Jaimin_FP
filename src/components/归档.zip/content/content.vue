<template>
  <div class="content-landing--container">
    <p class="content-landing--title">Content Management</p>
    <div class="content-landing--router_container">
      <router-link to="/content/itinerary-list">
        <div class="router-item--container item1">Itinerary</div>
      </router-link>
      <router-link to="/content/port-list">
        <div class="router-item--container item2">Ports</div>
      </router-link>
      <router-link to="/content/ship-list">
        <div class="router-item--container item3">Ships</div>
      </router-link>
    </div>
  </div>
</template>

<script>
  export default {
    data() {
      return {

      };
    },
    methods: {

    },
  };
</script>
