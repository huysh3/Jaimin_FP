<template>
  <div class="ship-list--container list--container">
    <header class="itinerary-list--header list--header">
      <span class="header--left-part">Ships ({{ship_list_data.length}})</span>
      <router-link to="/content/add-ship">
        <el-button class="costa-btn_blue">Add Ship +</el-button>
      </router-link>
    </header>
    <el-table
      :data="ship_list_data"
      border
      style="width: 100%"
      >
      <el-table-column
        prop="ship_id"
        label="Ship id"
        sortable>
      </el-table-column>
      <el-table-column
        prop="ship_name"
        label="Ship name"
        sortable>
      </el-table-column>
      <el-table-column
        label="Options">
        <template scope="scope">
          <el-button
            @click.native.prevent="routerGoEdit(scope)"
            type="text"
            size="small">
            Edit
          </el-button>
        </template>
      </el-table-column>      
    </el-table>    
  </div>
</template>

<script>
  import axios from 'axios';

  const domain = 'https://18546245.qcloud.la';

  export default {
    data() {
      return {
        ship_list_data: [],
      };
    },
    mounted() {
      this.getShipList();
    },
    methods: {
      getShipList() {
        axios.get(`${domain}/CMS/Ship/getShipList`)
            .then((res) => {
              if (res.data.code === 1) {
                this.ship_list_data = res.data.data;
              } else {
                this.$message.error(res.data.msg);
              }
            })
            .catch((err) => {
              this.$message.error(err);
            });
      },
      routerGoEdit(scope) {
        console.log(scope.$index);
        console.log(scope);
        this.$router.push({
          name: 'editShip',
          params: {
            ship_id: scope.row.ship_id,
          },
        });
      },
    },
  };
</script>