<template>
  <div class="port-list--container list--container">
    <header class="itinerary-list--header list--header">
      <span class="header--left-part">Ports ({{port_list_data.length}})</span>
      <router-link to="/content/add-port">
        <el-button class="costa-btn_blue">Add Port +</el-button>
      </router-link>
    </header>
    <el-table
      :data="port_list_data"
      border
      style="width: 100%"
      >
      <el-table-column
        prop="port_id"
        label="Port id"
        sortable>
      </el-table-column>
      <el-table-column
        prop="port_name"
        label="Port name"
        sortable>
      </el-table-column>
      <el-table-column
        label="Options">
        <template scope="scope">
          <el-button
            @click.native.prevent="routerGoEditPort(scope)"
            type="text"
            size="small">
            Edit
          </el-button>
        </template>
      </el-table-column>      
    </el-table>    
  </div>
</template>

<script>
  import axios from 'axios';

  const domain = 'https://18546245.qcloud.la';

  export default {
    data() {
      return {
        port_list_data: [],
      };
    },
    mounted() {
      this.getPortList();
    },
    methods: {
      getPortList() {
        axios.get(`${domain}/CMS/Port/getPortList`)
            .then((res) => {
              if (res.data.code === 1) {
                console.log(res.data.data);
                this.port_list_data = res.data.data;
              } else {
                this.$message.error(res.data.msg);
              }
            })
            .catch((err) => {
              this.$message.error(err);
            });
      },
      routerGoEditPort(scope) {
        console.log(scope.row.port_id);
        this.$router.push({
          name: 'editPort',
          params: {
            port_id: scope.row.port_id,
          },
        });
      },
    },
  };
</script>