<template>
  <div class="add-itinerary--container">
    <form id="form">
      <input id="js-file" type="file" style="display:none;"/>
    </form>
    <header class="add-itinerary--title">
      Add Itinerary
    </header>
    <section class="day-input--container">
      <el-row :gutter="40">
        <el-col :span="4" class="input--container">
          <div class="title">Days</div>
          <el-input v-model="day">
            <template slot="prepend">
              <span @click="day <= 0 ? '' : day --">-</span>
            </template>
            <template slot="append" @click="day ++">
              <span @click="day ++">+</span>
            </template>
          </el-input>
        </el-col>
        <el-col :span="4" class="input--container">
          <div class="title">Nights</div>
          <el-input v-model.number="night">
            <template slot="prepend">
              <span @click="night <= 0 ? '' : night --;">-</span>
            </template>
            <template slot="append">
              <span @click="night ++">+</span>
            </template>
          </el-input>
        </el-col>
        <el-col :span="4" class="input--container">
          <div class="title">Ship Select</div>
          <el-select v-model="itineraryInfo.itinerary_ship" placeholder="请选择">
            <el-option
              v-for="item in options"
              :key="item.value"
              :value="item.value">
            </el-option>
          </el-select>
        </el-col>
      </el-row>
    </section>

    <section class="route-manage--container">
      <div class="title">Route</div>
      <el-row class="route-input--content" :gutter="70">
        <el-col :span="6" v-for="(n, $index) in day" :key="n">
          <div class="subtitle" v-if="n == 1">Port</div>
          <div class="subtitle" v-if="n != 1">Day {{n}}</div>
          <el-input v-model="schedule[$index].port_id"></el-input>
        </el-col>
      </el-row>
    </section>

    <section class="image-manage--container">
      <el-row>
        <el-col :span="6" class="upload-img--container">
          <div class="upload-img--title">Map Image</div>
          <img @click="uploadImg('itinerary_map')" :src="itineraryInfo.itinerary_map || 'https://ws1.sinaimg.cn/large/006tNc79ly1fk1zqgezl8j305k05kt8i.jpg'" class="uplaod--btn"></img>
        </el-col>
        <el-col :span="6" class="upload-img--container">
          <div class="upload-img--title">Trip Image</div>
          <img @click="uploadImg('itinerary_img')" :src="itineraryInfo.itinerary_img || 'https://ws1.sinaimg.cn/large/006tNc79ly1fk1zqgezl8j305k05kt8i.jpg'" class="uplaod--btn"></img>
        </el-col>
        <el-col :span="6" class="upload-img--container">
          <div class="upload-img--title">Card Image</div>
          <img @click="uploadImg('itinerary_banner')" :src="itineraryInfo.itinerary_banner || 'https://ws1.sinaimg.cn/large/006tNc79ly1fk1zqgezl8j305k05kt8i.jpg'" class="uplaod--btn"></img>
        </el-col>
      </el-row>
    </section>
    <section class="options--container">
      <el-button @click="saveItinerary" size="small" class="costa-btn_primary">Save</el-button>
      <el-button size="small" class="costa-btn_default">Cancel</el-button>
    </section>
  </div>
</template>

<script>
  import axios from 'axios';
  import Cos from 'cos-js-sdk-v4';
  import $ from 'jquery';

  const domain = 'https://18546245.qcloud.la';
  const myFolder = '/Costa-CMS-1/';
  let cos;

  const errorCallBack = function (result) {
    console.log('request error:', result && result.message);
    $('#result').val(result.responseText || 'error');
  };

  const progressCallBack = function (curr, sha1) {
    const sha1CheckProgress = `${((sha1 * 100).toFixed(2) || 100)}%`;
    const uploadProgress = `${((curr || 0) * 100).toFixed(2)}%`;
    const msg = `upload progress:${uploadProgress}; sha1 check:${sha1CheckProgress}.`;
    console.log(msg);
    $('#result').val(msg);
  };

  const taskReady = function (taskId) {
    console.log(taskId);
  };

  export default {
    data() {
      return {
        options: [{
          value: '赛琳娜号',
        }, {
          value: '大西洋号',
        }, {
          value: '维多利亚号',
        }, {
          value: '幸运号',
        }],
        selectShip: '',
        itineraryInfo: {},
        inputDays: 0,
        inputNights: 0,
        dialogImageUrl: '',
        dialogVisible: false,
        day: 0,
        night: 0,
        schedule2: [],
        schedule: [],
        schedule_demo: {
          day: null,
          flag: null,
          itinerary_id: null,
          marks: null,
          port_id: null,
          schedule_id: null,
        },
        upload_img_url: '',
      };
    },
    watch: {
      day(newVal) {
        this.night = newVal - 1 ? newVal - 1 : 0;
      },
    },
    mounted() {
      if (this.$route.name === 'editItinerary') {
        this.getItineraryInfo(this.$route.params.itinerary_id);
      } else {
        this.getItineraryInfo();
      }
      cos = new Cos({
        appid: '1254092492',
        bucket: 'costacms',
        region: 'gz',
        getAppSign(callback) {
          axios.get(`${domain}/CMS/Bucket/makeSign`)
              .then((res) => {
                console.log(res.data.data);
                callback(res.data.data);
              })
              .catch((err) => {
                this.$message.error(err);
              });
        },
      });
      this.scheduleGenerator();
    },
    methods: {
      scheduleGenerator() {
        for (let i = 1; i < 15; i += 1) {
          this.schedule.push({
            day: String(i),
            flag: 1,
            itinerary_id: null,
            marks: null,
            port_id: null,
            schedule_id: null,
          });
        }
      },
      async getItineraryInfo(itineraryId) {
        const that = this;
        const params = itineraryId ? `itinerary_id=${itineraryId}` : '';
        await axios.get(`${domain}/CMS/Itinerary/generate?${params}`)
                  .then((res) => {
                    if (res.data.code === 1) {
                      this.itineraryInfo = res.data.data;
                      this.day = parseInt(res.data.data.itinerary_duration.split('天')[0], 10);
                      this.night = parseInt(res.data.data.itinerary_duration.split('天')[1], 10);

                      if (this.$route.name === 'editItinerary') {
                        const idx = this.schedule;
                        res.data.data.itinerary_schedule.map((item) => {
                          that.schedule.map((subItem, index) => {
                            console.log(`${subItem.day}-----${index}------${item.day}`);
                            if (subItem.day === item.day) {
                              idx[index] = item;
                            }
                            return this;
                          });
                          return this;
                        });
                        console.log(idx);
                        this.schedule = idx;
                      }
                    } else {
                      this.$message.error(res.data.msg);
                    }
                  })
                  .catch((err) => {
                    this.$message.error(err);
                  });
      },
      uploadImg(ori) {
        $('#js-file').off('change').on('change', (e) => {
          const file = e.target.files[0];
          // insertOnly==0 表示允许覆盖文件 1表示不允许
          cos.uploadFile(
            (res) => {
              console.log(res.data.access_url);
              this.itineraryInfo[ori] = res.data.access_url;
              console.log(this.imgs);
            },
            errorCallBack,
            progressCallBack,
            'costacms',
            myFolder + file.name,
            file,
            0,
            taskReady,
          );
          $('#form')[0].reset();
          return false;
        });
        setTimeout(() => {
          $('#js-file').click();
        }, 0);
        return false;
      },
      bindScheInput($event, n) {
        console.log(`第${n}个, 输入为${$event}`);
        console.log(this.schedule[n - 1]);
      },
      saveItinerary() {
        const scheduleResult = this.schedule.filter(item => item.port_id > 0);
        console.info('result', scheduleResult);
        this.itineraryInfo.itinerary_duration = `${this.day}天${this.night}夜`;
        this.itineraryInfo.itinerary_schedule = this.schedule.filter(item => item.port_id > 0);
        console.log(this.itineraryInfo);
        console.log(this.schedule);
        axios.post(`${domain}/CMS/Itinerary/updateItinerary`, this.itineraryInfo)
            .then((res) => {
              if (res.data.code === 1) {
                this.$message(res.data.msg);
                this.$router.push({
                  name: 'itineraryList',
                });
              } else {
                this.$message.error(res.data.msg);
              }
            })
            .catch((err) => {
              this.$message.err(err);
            });
      },
    },
  };
</script>