<template>
  <div class="itinerary-list--container list--container">
    <header class="itinerary-list--header list--header">
      <span class="header--left-part">Itineraties ({{itinerary_list_data.length}})</span>
      <router-link to="/content/add-itinerary">
        <el-button class="costa-btn_blue">Add Itinerary +</el-button>
      </router-link>
    </header>
    <el-table
      :data="itinerary_list_data"
      border
      style="width: 100%"
      >
      <el-table-column
        prop="itinerary_id"
        label="Itinerary id"
        sortable>
      </el-table-column>
      <el-table-column
        prop="itinerary_ship"
        label="Ship name"
        sortable>
      </el-table-column>
      <el-table-column
        prop="itinerary_name"
        label="Route"
        sortable>
      </el-table-column>
      <el-table-column
        label="Options">
        <template scope="scope">
          <el-button
            @click.native.prevent="routerGoEdit(scope)"
            type="text"
            size="small">
            Edit
          </el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
  import axios from 'axios';

  const domain = 'https://18546245.qcloud.la';

  export default {
    data() {
      return {
        itinerary_list_data: [],
      };
    },
    async mounted() {
      await this.getItineraryList();
    },
    methods: {
      async getItineraryList() {
        await axios.get(`${domain}/CMS/Itinerary/getItineraryList`)
                  .then((res) => {
                    if (res.data.code === 1) {
                      console.log(res.data.data);
                      this.itinerary_list_data = res.data.data;
                    } else {
                      this.$message.error(res.data.msg);
                    }
                  })
                  .catch((err) => {
                    this.$message.error(err);
                  });
      },
      routerGoEdit(scope) {
        console.log(scope.row.itinerary_id);
        this.$router.push({
          name: 'editItinerary',
          params: {
            itinerary_id: scope.row.itinerary_id,
          },
        });
      },
    },
  };
</script>