<template>
  <div class="add-ship--container">
    <form id="form">
      <input id="js-file" type="file" style="display:none;"/>
    </form>
    <header class="add-ship--title">
      Add Ship
      <el-switch
        v-model="shipInfo.flag"
        on-value="1"
        off-value="0"
        on-text="on"
        off-text="off"
        on-color="#13ce66"
        off-color="#ff4949">
      </el-switch>
    </header>
    <el-row class="ship-input--container">
      <el-col :span="6">
        <div class="title">Ship Name</div>
        <el-input v-model="shipInfo.ship_name"></el-input>
      </el-col>
    </el-row>
    <section class="image-manage--container">
      <el-row>
        <el-col :span="6" class="upload-img--container">
          <div class="upload-img--title">Ship Banner</div>
          <img @click="uploadImg('ship_banner')" :src="shipInfo.ship_banner || 'https://ws1.sinaimg.cn/large/006tNc79ly1fk1zqgezl8j305k05kt8i.jpg'" class="uplaod--btn"></img>
        </el-col>
      </el-row>
    </section>

    <section class="room-manage--container">
      <div class="title">Room</div>
      <el-row class="room-input--content" :gutter="70">
        <el-col :span="6" v-for="(item, $index) in shipInfo.room_list" :key="$index">
          <div class="subtitle">Room 1 Name</div>
          <el-input v-model="item.room_name"></el-input>
        </el-col>
      </el-row>
    </section>

    <section class="image-manage--container">
      <el-row class="image-upload--content">
        <el-col :span="6" class="upload-img--container" v-for="(item, $index) in shipInfo.room_list" :key="$index">
          <div class="upload-img--title">Room 1 Image</div>
          <img @click="uploadImg('room-' + $index)" :src="item.room_img || 'https://ws1.sinaimg.cn/large/006tNc79ly1fk1zqgezl8j305k05kt8i.jpg'" class="uplaod--btn"></img>
        </el-col>
      </el-row>
    </section>
    <section class="options--container">
      <el-button @click="saveBtnHandler" size="small" class="costa-btn_primary">Save</el-button>
      <el-button size="small" class="costa-btn_default">Cancel</el-button>
    </section>
  </div>
</template>

<script>
  import axios from 'axios';
  import $ from 'jquery';
  import Cos from 'cos-js-sdk-v4';

  const domain = 'https://18546245.qcloud.la';
  const myFolder = '/Costa-CMS-1/';
  let cos;

  const errorCallBack = function (result) {
    // result = result || {};
    console.log('request error:', result && result.message);
    $('#result').val(result.responseText || 'error');
  };

  const progressCallBack = function (curr, sha1) {
    const sha1CheckProgress = `${((sha1 * 100).toFixed(2) || 100)}%`;
    const uploadProgress = `${((curr || 0) * 100).toFixed(2)}%`;
    const msg = `upload progress:${uploadProgress}; sha1 check:${sha1CheckProgress}.`;
    console.log(msg);
    $('#result').val(msg);
  };

  const taskReady = function (taskId) {
    console.log(taskId);
  };

  export default {
    data() {
      return {
        selectShip: '',
        inputDays: 0,
        inputNights: 0,
        shipInfo: {},
        room_list: [{
          flag: '1',
          room_banner: 'https://om536p71r.qnssl.com/Bitmap4@1.5x.png',
          room_desc: 'http://via.placeholder.com/1125x3000',
          room_flag: '1',
          room_id: '1',
          room_img: '',
          room_name: '',
          room_price: '3299',
          room_ship: '赛琳娜号',
          room_type: '内舱房',
          ship_id: '2',
        }, {
          flag: '1',
          room_banner: 'https://om536p71r.qnssl.com/Bitmap4@1.5x.png',
          room_desc: 'http://via.placeholder.com/1125x3000',
          room_flag: '1',
          room_id: '1',
          room_img: '',
          room_name: '',
          room_price: '3299',
          room_ship: '赛琳娜号',
          room_type: '内舱房',
          ship_id: '2',
        }, {
          flag: '1',
          room_banner: 'https://om536p71r.qnssl.com/Bitmap4@1.5x.png',
          room_desc: 'http://via.placeholder.com/1125x3000',
          room_flag: '1',
          room_id: '1',
          room_img: '',
          room_name: '',
          room_price: '3299',
          room_ship: '赛琳娜号',
          room_type: '内舱房',
          ship_id: '2',
        }, {
          flag: '1',
          room_banner: 'https://om536p71r.qnssl.com/Bitmap4@1.5x.png',
          room_desc: 'http://via.placeholder.com/1125x3000',
          room_flag: '1',
          room_id: '1',
          room_img: '',
          room_name: '',
          room_price: '3299',
          room_ship: '赛琳娜号',
          room_type: '内舱房',
          ship_id: '2',
        }],
      };
    },
    async mounted() {
      if (this.$route.name === 'editShip') {
        await this.getShipInfo(this.$route.params.ship_id);
      } else {
        await this.getShipInfo();
        for (let i = 0; i < this.room_list.length; i += 1) {
          this.room_list[i].ship_id = this.$route.params.ship_id;
          this.room_list[i].room_ship = this.shipInfo.ship_name;
        }
        // this.room_list.map((item) => {
        //   console.log(item.ship_id);
        //   item.ship_id = 1;
        //   return this;
        // });
        this.shipInfo.room_list = this.room_list;
        console.log(this.shipInfo);
      }
      await this.configUpload();
    },
    methods: {
      configUpload() {
        cos = new Cos({
          appid: '1254092492',
          bucket: 'costacms',
          region: 'gz',
          getAppSign(callback) {
            // 方法一（推荐线上使用）：搭建鉴权服务器，构造请求参数获取签名，推荐实际线上业务使用，优点是安全性好，不会暴露自己的私钥
            // $.get('https://18546245.qcloud.la/CMS/Bucket/makeSign', callback);
            axios.get(`${domain}/CMS/Bucket/makeSign`)
                .then((res) => {
                  console.log(res.data.data);
                  callback(res.data.data);
                })
                .catch((err) => {
                  this.$message.error(err);
                });
          },
        });
      },
      async getShipInfo(shipId) {
        const params = shipId ? `ship_id=${shipId}` : '';
        await axios.get(`${domain}/CMS/Ship/generate?${params}`)
            .then((res) => {
              if (res.data.code === 1) {
                console.log(res.data.data);
                this.shipInfo = res.data.data;
              } else {
                this.$message.error(res.data.msg);
              }
            })
            .catch((err) => {
              this.$message.error(err);
            });
      },
      uploadImg(params) {
        $('#js-file').off('change').on('change', (e) => {
          const file = e.target.files[0];
          // insertOnly==0 表示允许覆盖文件 1表示不允许
          cos.uploadFile(
            (res) => {
              if (params === 'ship_banner') {
                this.shipInfo.ship_banner = res.data.access_url;
              } else {
                this.shipInfo.room_list[params.split('-')[1]].room_img = res.data.access_url;
              }
              console.log(res.data.access_url);
              console.log(this.imgs);
            },
            errorCallBack,
            progressCallBack,
            'costacms',
            myFolder + file.name,
            file,
            0,
            taskReady,
          );
          $('#form')[0].reset();
          return false;
        });
        setTimeout(() => {
          $('#js-file').click();
        }, 0);
        return false;
      },
      saveBtnHandler() {
        console.log(this.shipInfo);
        if (this.$route.name === 'addShip') {
          for (let i = 0; i < this.room_list.length; i += 1) {
            this.room_list[i].ship_id = this.$route.params.ship_id;
            this.room_list[i].room_ship = this.shipInfo.ship_name;
            this.room_list[i].room_id = '';
          }
        }
        axios.post(`${domain}/CMS/Ship/updateShip`, this.shipInfo)
            .then((res) => {
              if (res.data.data) {
                this.$message(res.data.msg);
                this.$router.push({
                  name: 'shipList',
                });
              } else {
                this.$message.error(res.data.msg);
              }
            })
            .catch((err) => {
              this.$message.error(err);
            });
      },
    },
  };
</script>