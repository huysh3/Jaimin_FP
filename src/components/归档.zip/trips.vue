<template>
  <div class="trips--container">
    <nav class="trips--nav">
      <span
        class="nav--left-part"
        :class="navStatus == 'active' ? 'active' : ''"
        @click="getTripList($event, 'active')">
          <i class="iconfont">&#xe640;</i> Active Trips
      </span>
      <span
        class="nav--right-part"
        :class="navStatus == 'history' ? 'active' : ''"
        @click="getTripList($event, 'history')">
          History Trips 
        <i class="iconfont">&#xe600;</i>
      </span>
    </nav>
    <el-table
      :data="trip_table_data"
      class="trips--table-container"
      border>
      <el-table-column
        prop="trip_departure_date"
        label="date"
        sortable>
      </el-table-column>
      <el-table-column
        prop="trip_id"
        label="trip_id">
      </el-table-column>
      <el-table-column
        prop="trip_itinerary_id"
        label="itinerary_id">
      </el-table-column>
      <el-table-column
        prop="itinerary_port"
        label="port">
      </el-table-column>
      <el-table-column
        prop="itinerary_duration"
        label="duration"
        width="180">
      </el-table-column>
      <el-table-column
        prop="itinerary_ship"
        label="ship"
        :filters="ship_filter"
        :filter-method="filterTag"
        filter-placement="bottom-end">
      </el-table-column>
      <el-table-column
        label="Options">
        <template scope="scope">
          <el-button
            @click.native.prevent="routerGoAddTrip(scope)"
            type="text"
            size="small">
            Edit
          </el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
  import axios from 'axios';

  export default {
    data() {
      return {
        trip_table_data: [],
        navStatus: 'active',
        ship_filter: [{
          text: '赛琳娜号',
          value: '赛琳娜号',
        }, {
          text: '大西洋号',
          value: '大西洋号',
        }, {
          text: '维多利亚号',
          value: '维多利亚号',
        }, {
          text: '幸运号',
          value: '幸运号',
        }],
      };
    },
    mounted() {
      this.getTripList();
    },
    methods: {
      formatter(row, column) {
        console.log('row', row);
        console.log('column', column);
        return row.address;
      },
      filterTag(value, row) {
        console.log('value', value);
        console.log('row', row);
        return row.itinerary_ship === value;
      },
      getTripList($event, status) {
        const url = `https://18546245.qcloud.la/CMS/Trip/getTripList?${status === 'history' ? 'history=1' : ''}`;
        if (status === 'history') {
          this.navStatus = 'history';
        } else {
          this.navStatus = 'active';
        }
        axios.get(url)
            .then((res) => {
              if (res.data.code === 1) {
                console.log(res.data.data);
                this.trip_table_data = res.data.data;
              }
            })
            .catch((err) => {
              console.log(err);
            });
      },
      routerGoAddTrip(scope) {
        console.log(scope.row.trip_id);
        this.$router.push({
          name: 'editTrip',
          params: {
            trip_id: scope.row.trip_id,
          },
        });
        // this.$router.push({
        //   name: 'addTrips',
        //   params: { trip_id: scope.row.trip_id },
        // });
      },
    },
  };
</script>