<template>
  <div class="add-trips--container">
    <section class="add-trips--part-content">
      <header class="content--header">
        <span class="header--icon">1</span> Select Itinerary
      </header>
      <div class="content--body">
        <div class="block">
          <el-date-picker
            v-model="trip_info.trip_departure_date"
            type="date"
            placeholder="Select Date"
            :picker-options="pickerOptions">
          </el-date-picker>
          <el-button
            @click="selectItineraryModalStatus = true"
            class="costa-btn_blue select-itinerary--btn">
              {{trip_info.itinerary && trip_info.itinerary.itinerary_name ? trip_info.itinerary.itinerary_name : 'Select Itinerary'}}
          </el-button>
        </div>
      </div>
    </section>
    <section class="add-trips--part-content" v-if="JSON.stringify(trip_info) !== '{}'">
      <header class="content--header">
        <span class="header--icon">2</span> Enter Room Price
      </header>
      <div class="content--body">
        <el-table
          :data="trip_info.bed_list"
          border>
          <el-table-column
            label="Bed Name"
            prop="bed_name">
            <template scope="scope">
              <el-popover trigger="click" placement="top">
                <div class="room-price--popover_container">
                  <el-input v-model="scope.row.bed_name"></el-input>
                  <el-button size="mini" type="primary" @click="setRoomPriceChange(scope)">确定</el-button>
                </div>
                <div slot="reference" class="name-wrapper">
                  {{ scope.row.bed_name }}
                </div>
              </el-popover>
            </template>
          </el-table-column>
          <el-table-column
            label="Bed People"
            prop="bed_people">
            <template scope="scope">
              <el-popover trigger="click" placement="top">
                <div class="room-price--popover_container">
                  <el-input v-model="scope.row.bed_people"></el-input>
                  <el-button size="mini" type="primary" @click="setRoomPriceChange(scope)">确定</el-button>
                </div>
                <div slot="reference" class="name-wrapper">
                  {{ scope.row.bed_people }}
                </div>
              </el-popover>
            </template>
          </el-table-column>
          <el-table-column
            label="Bed Price"
            prop="bed_price">
            <template scope="scope">
              <el-popover trigger="click" placement="top">
                <div class="room-price--popover_container">
                  <el-input v-model="scope.row.bed_price"></el-input>
                  <el-button size="mini" type="primary" @click="setRoomPriceChange(scope)">确定</el-button>
                </div>
                <div slot="reference" class="name-wrapper">
                  {{ scope.row.bed_price }}
                </div>
              </el-popover>
            </template>
          </el-table-column>
          <el-table-column
            label="Bed Price Quad"
            prop="bed_price_quad">
            <template scope="scope">
              <el-popover trigger="click" placement="top">
                <div class="room-price--popover_container">
                  <el-input v-model="scope.row.bed_price_quad"></el-input>
                  <el-button size="mini" type="primary" @click="setRoomPriceChange(scope)">确定</el-button>
                </div>
                <div slot="reference" class="name-wrapper">
                  {{ scope.row.bed_price_quad }}
                </div>
              </el-popover>
            </template>
          </el-table-column>
          <el-table-column
            label="Bed Extra Price"
            prop="bed_extra_price">
            <template scope="scope">
              <el-popover trigger="click" placement="top">
                <div class="room-price--popover_container">
                  <el-input v-model="scope.row.bed_extra_price"></el-input>
                  <el-button size="mini" type="primary" @click="setRoomPriceChange(scope)">确定</el-button>
                </div>
                <div slot="reference" class="name-wrapper">
                  {{ scope.row.bed_extra_price || '0' }}
                </div>
              </el-popover>
            </template>
          </el-table-column>
          <el-table-column
            label="Bed Child Price"
            prop="bed_child_price">
            <template scope="scope">
              <el-popover trigger="click" placement="top">
                <div class="room-price--popover_container">
                  <el-input v-model="scope.row.bed_child_price"></el-input>
                  <el-button size="mini" type="primary" @click="setRoomPriceChange(scope)">确定</el-button>
                </div>
                <div slot="reference" class="name-wrapper">
                  {{ scope.row.bed_child_price || '0' }}
                </div>
              </el-popover>
            </template>
          </el-table-column>
          <el-table-column
            label="Individual Percent"
            prop="bed_individual_percent"
            width="200">
            <template scope="scope">
              <el-popover trigger="click" placement="top">
                <div class="room-price--popover_container">
                  <el-input v-model="scope.row.bed_individual_percent"></el-input>
                  <el-button size="mini" type="primary" @click="setRoomPriceChange(scope)">确定</el-button>
                </div>
                <div slot="reference" class="name-wrapper">
                  {{ scope.row.bed_individual_percent }}
                </div>
              </el-popover>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </section>
    <section class="add-trips--part-content">
      <header class="content--header">
        <span class="header--icon">3</span> Enter Other expenses
      </header>
      <div class="content--body">
        <el-row>
          <el-col :span="6">
            <el-input placeholder="请输入内容" v-model="trip_info.trip_port_charge" size="large">
              <template slot="prepend" class="input--left-part">Port Charge （￥）</template>
            </el-input>
          </el-col>
        </el-row>
      </div>
    </section>
    <section class="add-trip--options-content">
      <el-button size="small" class="costa-btn_primary" @click="saveEventHandler">Save</el-button>
      <el-button size="small" class="costa-btn_default">Cancel</el-button>
    </section>

    <!-- dialog -->
    <el-dialog title="Select Itinerary" :visible.sync="selectItineraryModalStatus" size="small">
      <el-table :data="itinerary_table_list">
        <el-table-column property="itinerary_id" label="Itinerary ID" width="120"></el-table-column>
        <el-table-column property="itinerary_ship" label="Ship" width="150"></el-table-column>
        <el-table-column property="itinerary_name" label="Route"></el-table-column>
        <el-table-column label="Options" width="100">
          <template scope="scope">
            <el-button
              @click.native.prevent="selectItinerary(scope)"
              type="text"
              size="small">
              Select
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-dialog>
  </div>
</template>

<script>
import axios from 'axios';

const domain = 'https://18546245.qcloud.la';

export default {
  data() {
    return {
      pickerOptions: {
        disabledDate(time) {
          return time.getTime() < Date.now() - 8.64e7;
        },
      },
      componentStatus: '',
      trip_info: {},
      room_price_data: [],
      itinerary_table_list: [],
      selectDate: '',
      selectItineraryModalStatus: false,
      index_trip_id: '',
      otherExpenses: {
        inputPortCharge: '',
        inputPermium: '',
        inputPermiumSuite: '',
      },
    };
  },
  async mounted() {
    console.log(this.$route.name);
    if (this.$route.name === 'addTrips') {
      await this.generateNewTrip();
      await this.getTripEdit(this.index_trip_id);
    } else {
      await this.getTripEdit(this.$route.params.trip_id);
    }
    await this.getItineraryList();
  },
  methods: {
    async generateNewTrip() {
      await axios.get(`${domain}/CMS/Trip/generateTrip`)
          .then((res) => {
            if (res.data.code === 1) {
              this.index_trip_id = res.data.data;
            }
            if (res.data.code !== 1) {
              this.$message.error(res.data.msg);
            }
          })
          .catch((err) => {
            this.$message.error(err);
          });
    },
    async fetchAddTrip() {
      await axios.get(`${domain}/CMS/Trip/addTrip`)
          .then((res) => {
            this.index_trip_id = res.data.data;
          })
          .catch((err) => {
            this.$message.error(err);
          });
    },
    async getItineraryList() {
      await axios.get(`${domain}/CMS/Itinerary/getItineraryList`)
          .then((res) => {
            if (res.data.code === 1) {
              this.itinerary_table_list = res.data.data;
              console.log('itinerary_table_list', this.itinerary_table_list);
            } else {
              this.$message.error(res.data.msg);
            }
          })
          .catch((err) => {
            console.log(err);
          });
    },
    async getTripEdit(tripId) {
      await axios.get(`${domain}/CMS/Trip/getTripEdit?trip_id=${tripId}`)
        .then((res) => {
          if (res.data.code === 1) {
            console.log(res.data.data);
            this.trip_info = res.data.data;
          } else {
            this.$message.error(res.data.msg);
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },
    setRoomPriceChange(scope) {
      console.log(scope);
      console.log(this.room_price_data);
    },
    async getRoomListByItiID(itineraryId) {
      await axios.get(`${domain}/CMS/Trip/getRoomList?itinerary_id=${itineraryId}`)
          .then((res) => {
            if (res.data.code === 1) {
              console.log('bed_list', res.data.data);
              this.trip_info.bed_list = res.data.data;
            } else {
              this.$message.error(res.data.msg);
            }
          })
          .catch((err) => {
            this.$message.error(err);
          });
    },
    async selectItinerary(scope) {
      this.trip_info.itinerary = scope.row;
      this.trip_info.trip_itinerary_id = scope.row.itinerary_id;
      this.selectItineraryModalStatus = false;
      await this.getRoomListByItiID(scope.row.itinerary_id);
    },
    async saveEventHandler() {
      const newDate = this.trip_info.trip_departure_date;
      if (this.trip_info.trip_departure_date && this.trip_info.trip_departure_date.toString().split('-').length !== 3) {
        this.trip_info.trip_departure_date = `${newDate.getFullYear()}-${newDate.getMonth() + 1}-${newDate.getDate()}`;
      }
      this.trip_info.trip_flag = 1;
      delete this.trip_info.itinerary;
      await this.saveChangeEvent();
    },
    async saveChangeEvent() {
      const headers = {
        // 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
      };
      await axios.post(`${domain}/CMS/Trip/${this.$route.name === 'addTrips' ? 'addTrip' : 'editTrip'}`, this.trip_info, headers)
          .then((res) => {
            if (res.data.code === 1) {
              console.log(res.data.data);
              this.$router.push({
                name: 'trips',
              });
            } else {
              this.$message.error(res.data.msg);
            }
          })
          .catch((err) => {
            this.$message.error(err);
          });
    },
  },
};
</script>
