<template>
  <div class="element-test--container">
    <h1>{{msg}}</h1>
    <el-button>默认按钮</el-button>
    <el-button type="primary">主要按钮</el-button>
    <el-button type="text">文字按钮</el-button>
  </div>  
</template>

<script>
export default {
  name: 'hello',
  data() {
    return {
      msg: 'Element Test',
    };
  },
};
</script>

<style scoped lang="less">
h1 {
  margin: 0;
}
</style>